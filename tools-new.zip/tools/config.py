import sys
from pathlib import Path

BASE_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)

def get_json_path(filename):
    path = BASE_DIR / "info" / filename

    if not path.is_file():
        raise FileNotFoundError(f"Missing configuration: {path}")

    return path